let enemy;

function Enemy(enemyType, health, mana, strength, agility, speed) {
    this.classType = enemyType;
    this.health = health;
    this.mana = mana;
    this.strength = strength;
    this.agility = agility;
    this.speed = speed;
}
